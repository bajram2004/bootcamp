#opdeacht 1
name = input("wat is je naam ")
age = int(input("hoe oud ben je "))
leeftijd = age + 5
print ("hallo "+ name +" je bent over 5 jaar " + str(leeftijd) +" jaar oud.")

#opdracht 2
g1 = float(input ("kies een getal "))
g2 = float(input ("kies nog een getal "))
gem = (g1 + g2) / 2
print ("het gemiddelde is "+ str(gem))

#opdracht 3
woord = input ("voer een woord in ")
print ("Het woord is: "+ woord +" en bestaat uit " +str(len(woord))+ " tekens.")
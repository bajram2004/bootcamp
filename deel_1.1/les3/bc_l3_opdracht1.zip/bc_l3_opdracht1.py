

description = 'dag'

days = 1
hours = days * 24
minutes = hours * 60
seconds = minutes * 60

print(f'In een {description} zitten {seconds} seconden')
var1 = float(input())
var2 = float(input())
var3 = float(input())

gemiddelde = (var1 + var2 + var3) / 3
print(gemiddelde)
print(15+4)#optellen
print(15-4)#aftrekken
print(15*4)#vermenigvuldigen
print(15/4)#delen
print(15//4)#gehele deling
print(15**4)#machtsverheffing
print(15%4)#restant deling
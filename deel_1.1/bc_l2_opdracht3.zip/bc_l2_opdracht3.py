# We verwachten: 199.5126050420168
print (((12*13 /14) + (15 -16) /17) *18)

# Maak met de volgende reeks 5 verschillende uitkomsten,
# door haakjes op andere plekken te zetten
print( 2*3 /4 + 5 -6/7 *-1)
#1
print((2*3) /4 + 5 -6/7 *-1)
#2
print(2*(3 /4) + 5 -6/7 *-1)
#3
print(2*3 /(4 + 5) -6/7 *-1)
#4
print(2*3 / (4 + 5 - 6/7) *-1)
#5
print(2*3 /4 + (5 -6/7) *-1)

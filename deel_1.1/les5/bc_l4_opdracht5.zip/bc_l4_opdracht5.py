#opdracht 1
for i in range(1, 26):
    print(i)

#opdracht 2
for _ in range(20):
    print("Ik ben hard op weg developer te worden!")

#opdracht 3
total = 625
divisor = 25
count = 0
while total >= divisor:
    total -= divisor
    count += 1
print(count)
print (round( (431 / 100) * 100) ) 

#ik weet niet waarom python dat doet maar ik heb het wel gefixed
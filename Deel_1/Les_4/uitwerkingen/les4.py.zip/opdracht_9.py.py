aantal_kinderen =input("hoeveel kinderen betalen lesgeld ")
lesgeld =input("hoeveel les geld betaal je ")
resultaat = int(aantal_kinderen) * float(lesgeld)


print (round(resultaat))
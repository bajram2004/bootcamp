var1=25
var2=0
print (var1/var2)
print ("er komt te staan ZeroDivisionError: division by zero ")

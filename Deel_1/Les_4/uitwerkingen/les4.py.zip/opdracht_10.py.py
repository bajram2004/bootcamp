seconden_per_minuut = 60
seconden_per_uur = 60 * seconden_per_minuut
seconden_per_dag = 24 * seconden_per_uur
seconden_per_week = 7 * seconden_per_dag

dagen_per_jaar = 365

seconden_per_jaar = dagen_per_jaar * seconden_per_dag

print("Aantal seconden in een dag:", seconden_per_dag)
print("Aantal seconden in een week:", seconden_per_week)
print("Aantal seconden in een jaar:", seconden_per_jaar)
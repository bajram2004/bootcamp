print("wat is je naam")
var1 = input()
print ("hallo "+ var1 +", ik leer nu programmeren" )
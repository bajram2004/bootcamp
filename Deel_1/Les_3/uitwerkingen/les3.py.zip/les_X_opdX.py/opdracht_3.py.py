appels = 3.40
druiven = 2.45
bananen = 1.95
BTW = 9
appelsbtw = (appels / 100 * BTW)
appelstotaal = appels + appelsbtw
druivenbtw = (druiven / 100 * BTW)
druiventotaal = druiven + druivenbtw
bananenbtw = (bananen / 100 * BTW)
bananentotaal = bananen + bananenbtw
print (appelstotaal)
print (druiventotaal)
print (bananentotaal)
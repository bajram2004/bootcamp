print ( 5*2 -3+4/2 )
print ( 5*2 - 3+4 / 2 )

print ( (5*2) - (3+4) /2 )
print ( ((5*2) -(3+4)) / 2 )

print ("wat tussen haakjes staat gaat als eerst")
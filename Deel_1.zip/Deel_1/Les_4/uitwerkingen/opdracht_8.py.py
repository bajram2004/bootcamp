var1 = 265
var2 = 13
print (var1//var2)
print (var1%var2)